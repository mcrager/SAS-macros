library(testthat)
library(cshCIF)

test_check("cshCIF")

#' cshCIF a package for estimating the cause-specific hazard CIF.
#'
#' The cshCIF package provides a basic set of functions for carrying
#' out the estimation.
#'
#' Interface and functionality are subject to change.
#'
#' @docType package
#' @name cshCIF
NULL
